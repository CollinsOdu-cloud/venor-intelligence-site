VENOR INTELLIGENCE WEBSITE — STARTER FILE

Included:
- index.html: responsive, single-page website.
- This file is a starter template; contact details are placeholders and must be replaced before publishing.

HOW TO CUSTOMISE:
1. Open index.html in a text editor.
2. Find and replace:
   REPLACE_WITH_YOUR_EMAIL
   REPLACE_WITH_YOUR_BUSINESS_NUMBER
3. Also replace REPLACE_WITH_YOUR_EMAIL inside the mailto link with your actual email address.
4. Review every service description and only advertise work you can actually deliver.
5. Do not claim the business is incorporated until the company is legally registered.
6. Do not advertise regulated lending, investment management, deposit-taking or financial-advisory services unless properly authorised.

LOW-COST PUBLISHING:
- You can upload this file to a static website host that supports custom domains.
- Connect venorintelligence.com by following the host's official custom-domain instructions.
- Do not change Namecheap nameservers or DNS records blindly. Keep any existing email-related DNS records you need.
- Domain registration and website hosting are separate things; a domain alone does not publish a website.

This template is not legal or regulatory advice. Check the current Kenyan requirements for the services you intend to provide.
